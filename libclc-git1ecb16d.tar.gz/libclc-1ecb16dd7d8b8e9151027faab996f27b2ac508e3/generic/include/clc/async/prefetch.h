#define __CLC_BODY <clc/async/prefetch.inc>
#include <clc/async/gentype.inc>
#undef __CLC_BODY

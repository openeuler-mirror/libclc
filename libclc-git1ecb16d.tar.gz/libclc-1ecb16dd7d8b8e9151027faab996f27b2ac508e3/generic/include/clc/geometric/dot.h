#define __CLC_BODY <clc/geometric/dot.inc>
#include <clc/geometric/floatn.inc>

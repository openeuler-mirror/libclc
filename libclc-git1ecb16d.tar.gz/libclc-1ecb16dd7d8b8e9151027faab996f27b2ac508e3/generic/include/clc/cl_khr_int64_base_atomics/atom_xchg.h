#define __CLC_FUNCTION atom_xchg
#include <clc/atom_decl_int64.inc>

_CLC_DECL size_t get_local_size(uint dim);

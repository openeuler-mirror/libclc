_CLC_DECL size_t get_local_id(uint dim);

_CLC_DECL size_t get_num_groups(uint dim);

#define __CLC_BODY <clc/shared/min.inc>
#include <clc/integer/gentype.inc>

#define __CLC_BODY <clc/shared/min.inc>
#include <clc/math/gentype.inc>

_CLC_OVERLOAD _CLC_DECL int atomic_inc (volatile local int *);
_CLC_OVERLOAD _CLC_DECL int atomic_inc (volatile global int *);
_CLC_OVERLOAD _CLC_DECL uint atomic_inc (volatile local uint *);
_CLC_OVERLOAD _CLC_DECL uint atomic_inc (volatile global uint *);

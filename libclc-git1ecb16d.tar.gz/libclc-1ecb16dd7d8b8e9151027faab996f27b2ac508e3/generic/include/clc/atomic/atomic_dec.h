_CLC_OVERLOAD _CLC_DECL int atomic_dec (volatile local int *);
_CLC_OVERLOAD _CLC_DECL int atomic_dec (volatile global int *);
_CLC_OVERLOAD _CLC_DECL uint atomic_dec (volatile local uint *);
_CLC_OVERLOAD _CLC_DECL uint atomic_dec (volatile global uint *);

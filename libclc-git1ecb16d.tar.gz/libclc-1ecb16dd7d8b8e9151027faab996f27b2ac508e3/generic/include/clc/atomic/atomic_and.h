#define __CLC_FUNCTION atomic_and
#include <clc/atomic/atomic_decl.inc>

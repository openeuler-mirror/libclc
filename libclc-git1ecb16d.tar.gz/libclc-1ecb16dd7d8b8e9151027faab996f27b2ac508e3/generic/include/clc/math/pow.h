#define __CLC_FUNCTION pow
#define __CLC_BODY <clc/math/binary_decl_tt.inc>
#include <clc/math/gentype.inc>
#undef __CLC_BODY
#undef __CLC_FUNCTION

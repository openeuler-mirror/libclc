#define __CLC_BODY <clc/math/frexp.inc>
#include <clc/math/gentype.inc>

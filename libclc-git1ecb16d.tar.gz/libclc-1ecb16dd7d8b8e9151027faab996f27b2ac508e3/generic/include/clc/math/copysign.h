#define __CLC_BODY <clc/math/copysign.inc>
#include <clc/math/gentype.inc>

#define __CLC_BODY <clc/math/nextafter.inc>
#include <clc/math/gentype.inc>

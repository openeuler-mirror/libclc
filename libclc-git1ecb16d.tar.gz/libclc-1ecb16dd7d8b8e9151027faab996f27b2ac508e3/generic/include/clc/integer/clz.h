#define __CLC_BODY <clc/integer/clz.inc>
#include <clc/integer/gentype.inc>

#define __CLC_BODY <clc/integer/add_sat.inc>
#include <clc/integer/gentype.inc>

#define __CLC_BODY <clc/integer/mad_sat.inc>
#include <clc/integer/gentype.inc>
#undef __CLC_BODY

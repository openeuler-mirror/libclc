#define __CLC_FUNCTION __clc_native_popcount
#define __CLC_INTRINSIC "llvm.ctpop"
#include <integer/unary_intrin.inc>

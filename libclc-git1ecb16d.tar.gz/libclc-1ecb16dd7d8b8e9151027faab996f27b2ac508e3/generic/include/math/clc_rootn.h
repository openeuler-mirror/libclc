#define __CLC_BODY <math/clc_rootn.inc>
#include <clc/math/gentype.inc>
#undef __CLC_BODY

#define __CLC_FUNCTION __clc_fmod
#define __CLC_BODY <clc/math/binary_decl_tt.inc>
#include <clc/math/gentype.inc>
#undef __CLC_FUNCTION

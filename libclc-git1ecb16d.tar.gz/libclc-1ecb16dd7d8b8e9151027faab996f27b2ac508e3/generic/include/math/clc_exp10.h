#define __CLC_FUNCTION __clc_exp10
#define __CLC_BODY <clc/math/unary_decl.inc>
#include <clc/math/gentype.inc>
#undef __CLC_FUNCTION

#define __CLC_FUNCTION __clc_remquo

#define __CLC_BODY <clc/math/remquo.inc>
#define __CLC_ADDRESS_SPACE private
#include <clc/math/gentype.inc>
#undef __CLC_ADDRESS_SPACE

#undef __CLC_FUNCTION
